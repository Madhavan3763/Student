<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Student extends CI_Controller {

function __construct() {
     parent::__construct();   
     $this->load->library('form_validation');

     $this->load->model('Student_Model');
     }
     public function index()
     {
      $details_student=$this->Student_Model->get_student_details();
        $data['details_student']=$details_student;
        $this->load->view('lost/details',$data);

     }
     public function student_add()
     {  
       $this->load->view('lost/student_add');
     }
 
   public function save_student()
   {

    $this->form_validation->set_rules('student_name', 'Student Name', 'required');
$this->form_validation->set_rules('student_rollno', 'Student Roll Number', 'required');
$this->form_validation->set_rules('Mark_1', 'Mark 1', 'required|numeric');
$this->form_validation->set_rules('Mark_2', 'Mark 2', 'required|numeric');
$this->form_validation->set_rules('Mark_3', 'Mark 3', 'required|numeric');
$this->form_validation->set_rules('Mark_4', 'Mark 4', 'required|numeric');
$this->form_validation->set_rules('Mark_5', 'Mark 5', 'required|numeric');
if ($this->form_validation->run() === FALSE) {
  $this->load->view('lost/student_add');
 
} else {

    $id=$this->input->post('hiddenid'); 
    $data=array('student_name'=>$this->input->post('student_name'),
               'student_rollno'=>$this->input->post('student_rollno'),
                'Mark_1'=>$this->input->post('Mark_1'),
                 'Mark_2'=>$this->input->post('Mark_2'),
                  'Mark_3'=>$this->input->post('Mark_3'),
                   'Mark_4'=>$this->input->post('Mark_4'),
                   'Mark_5'=>$this->input->post('Mark_5')
                   );
                  $save_student=$this->Student_Model->save_student($data,$id);
                  redirect("Student/index");
   }
  }
   public function edit_student($id)
   {
      $edit_student=$this->Student_Model->edit_student($id);
      $data['edit_student']=$edit_student;
      $this->load->view('lost/student_add',$data);      
       }
       
       public function delete_student($id)
       {
        $delete_student=$this->Student_Model->delete_student($id);
        redirect("Student/index");
       }
} 
?>    