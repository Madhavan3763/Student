<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Student_Model extends CI_Model {

     public function get_student_details()
     {
          $query=$this->db->query("select * from student");
          if($query->num_rows() > 0){   
          return $query->result();
          }

          else{
               return false;
          }

     }    

     public function save_student($data,$id)
     {
          if($id==NULL){

          $query=$this->db->insert('student',$data);
          }else
          {
               $this->db->where('student_id',$id);
               $query=$this->db->update('student',$data);
          }
          if($query)
          {

             return ture;
          }else
          {
           return false;
          }
     }
     public function edit_student($id)
     {
          $query=$this->db->query('select * from student  Where student_id='.$id);
          if($query->num_rows()>0)      
          {
               return  $query->row();
          }else
          {
               return false;
          }    
     }
     public function delete_student($id)
     {
          $query=$this->db->query("delete from student Where student_id=".$id);
          return 1; 
     }
}

?>