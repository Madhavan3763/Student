<?php
error_reporting(0);
?>
<!DOCTYPE html>
<html lang="en">
<head>
     <meta charset="UTF-8">
     <meta http-equiv="X-UA-Compatible" content="IE=edge">
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <title>Student Details</title>    
     <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
</head>
<body>


<div class="container">
     <button class="btn btn-primary my-5"><a href="<?php echo base_url();?>Student/student_add"
      class="text-light"> Add user </a>
     </button>
<table class="table">
  <thead>
    <tr>
    <th scope="col">student_id</th>
      <th scope="col">student_name</th>
      <th scope="col">student_rollno</th>
      <th scope="col">Mark 1</th>
      <th scope="col">Mark 2</th>
      <th scope="col">Mark 3</th>
      <th scope="col">Mark 4</th>
      <th scope="col">Mark 5</th>
      <th scope="col">operators</th>


    </tr>
  </thead>  
  <tbody>

  <?php
foreach ($details_student as $student_list){?>
        <tr>
        <th scope="row"><?php echo $student_list->student_id;?></th>
       <td><?php echo $student_list->student_name;?></td>
        <td><?php echo $student_list->student_rollno;?></td>
        <td><?php echo $student_list->Mark_1;?></td>
        <td><?php echo $student_list->Mark_2;?></td>
        <td><?php echo $student_list->Mark_3;?></td>
        <td><?php echo $student_list->Mark_4;?></td>
        <td><?php echo $student_list->Mark_5;?></td>
        <td><button class="btn btn-primary"><a href="<?php echo base_url();?>Student/edit_student/<?php echo $student_list->student_id?>"class="text-light">Update</a></button>
         <button class="btn btn-danger"><a href="<?php echo base_url();?>Student/delete_student/<?php echo $student_list->student_id?>"class="text-light">Delete</a></button>
      </td>
      </tr>
      <?php
}

  ?>
 </tbody>
</table>
</div>
     
</body>
</html>