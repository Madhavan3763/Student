
<?php
error_reporting(0);
?>
<!DOCTYPE html>
<html lang="en">
<head>
     <meta charset="UTF-8">
     <meta http-equiv="X-UA-Compatible" content="IE=edge">
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <title>Document</title>
     <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
</head>
<body>
<form method='post' action="<?php echo base_url();?>Student/save_student">
  <div class="container my-5">
    <div class="form-group">
      <label>Student_name</label>
      <input type="text" class="form-control" placeholder="Enter your student name" name="student_name" value="<?php echo set_value('student_name', $edit_student->student_name); ?>">
      <?php echo form_error('student_name', '<span class="text-danger">', '</span>'); ?>
    </div>
    <div class="form-group">
      <label>Student_rollno</label>
      <input type="text" class="form-control" placeholder="Enter your student rollno" name="student_rollno" value="<?php echo set_value('student_rollno', $edit_student->student_rollno); ?>">
      <?php echo form_error('student_rollno', '<span class="text-danger">', '</span>'); ?>
    </div>
    <div class="form-group">
      <label>Mark_1</label>
      <input type="number" class="form-control" placeholder="Enter your Mark_1" name="Mark_1" value="<?php echo set_value('Mark_1', $edit_student->Mark_1); ?>">
      <?php echo form_error('Mark_1', '<span class="text-danger">', '</span>'); ?>
    </div>
    <div class="form-group">
      <label>Mark_2</label>
      <input type="number" class="form-control" placeholder="Enter your Mark_2" name="Mark_2" value="<?php echo set_value('Mark_2', $edit_student->Mark_2); ?>">
      <?php echo form_error('Mark_2', '<span class="text-danger">', '</span>'); ?>
    </div>
    <div class="form-group">
      <label>Mark_3</label>
      <input type="number" class="form-control" placeholder="Enter your Mark_3" name="Mark_3" value="<?php echo set_value('Mark_3', $edit_student->Mark_3); ?>">
      <?php echo form_error('Mark_3', '<span class="text-danger">', '</span>'); ?>
    </div>
    <div class="form-group">
      <label>Mark_4</label>
      <input type="number" class="form-control" placeholder="Enter your Mark_4" name="Mark_4" value="<?php echo set_value('Mark_4', $edit_student->Mark_4); ?>">
      <?php echo form_error('Mark_4', '<span class="text-danger">', '</span>'); ?>
    </div>
    <div class="form-group">
      <label>Mark_5</label>
      <input type="number" class="form-control" placeholder="Enter your Mark_5" name="Mark_5" value="<?php echo set_value('Mark_5', $edit_student->Mark_5); ?>">
      <?php echo form_error('Mark_5', '<span class="text-danger">', '</span>'); ?>
    </div>
    <input type="hidden" name="hiddenid" value="<?php echo $edit_student->student_id; ?>">
    <br>
    <button type="submit" class="btn btn-primary">Submit</button>
  </div>
</form>

</body>
</html>